[![Build Status](https://travis-ci.org/ParasiteTracker/vampire-moth-dwca.svg)](https://travis-ci.org/ParasiteTracker/vampire-moth-dwca) [![DOI](https://zenodo.org/badge/26293374.svg)](https://zenodo.org/badge/latestdoi/26293374) [![GloBI](http://api.globalbioticinteractions.org/interaction.svg?accordingTo=globi:ParasiteTracker/vampire-moth-dwca)](http://globalbioticinteractions.org/?accordingTo=globi:ParasiteTracker/vampire-moth-dwca) 

This repository provides an example on how to make your interaction data available through Global Biotic Interactions (GloBI, http://globalbioticinteractions.org).

