package org.trophic.graph.domain;

/**
* @author mh
* @since 12.03.11
*/
public enum Roles {
    ACTS_IN, DIRECTED
}
